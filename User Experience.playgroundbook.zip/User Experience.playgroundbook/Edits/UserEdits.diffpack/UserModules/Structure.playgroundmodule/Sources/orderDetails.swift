import SwiftUI

public struct orderDetails: View{
    @Environment(\.userPreferences) var customValues
    public init (){}
    public var body: some View{
        ZStack{ //content
            Rectangle()
            VStack{
                Text("Order Details") //(326.268, 699,44)
                    .frame(width: 300, alignment: .topTrailing)
                    .font(.system(size: 20, weight: self.customValues.orderTitleWidth, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.3411764705882353, green: 0.6235294117647059, blue: 0.16862745098039217, alpha: 1.0)))
                Divider()
                HStack{   //delivery
                    Spacer()
                        .frame(width: 30)
                    Image(systemName: "car")
                        .frame(width: 20, height: 20)
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                    Text("Delivery")
                        .frame(width: 300, alignment: .topLeading)
                        .font(.system(size: 14, weight: .regular, design: .default))
                        .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                }
                HStack{  //delivery time
                    Spacer()
                        .frame(width: 30)
                    Image(systemName: "stopwatch")
                        .frame(width: 20, height: 20)
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                    Text("Delivery Time: 15-25 min")
                        .frame(width: 300, alignment: .topLeading)
                        .font(.system(size: 14, weight: .regular, design: .default))
                        .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                }
                Divider()
                Spacer()
                orderPrice() // order price
                    .frame(height: 70)
                Spacer()
                ZStack{
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color(self.customValues.orderButtonColor))
                        .frame(width: 300, height: self.customValues.orderButtonHeight)
                    Text("Order Pizza")
                        .font(.system(size: self.customValues.orderButtomTextSize, weight: .regular, design: .default))
                        .foregroundColor(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                } 
                Spacer()
                    .frame(height: 10)
            }.frame(width: 300, height: 258)
        }
        .frame(width: 326.268, height:300)
    }
}
