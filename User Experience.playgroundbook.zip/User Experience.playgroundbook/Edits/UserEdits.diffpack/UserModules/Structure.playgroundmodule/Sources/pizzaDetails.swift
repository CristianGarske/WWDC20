import SwiftUI

public struct pizzaDetails: View{
    @Environment(\.userPreferences) var customValues
    public init() {}
    public var body: some View {
        VStack(alignment: .trailing, spacing: 18){
            Text("Margherita")
                .frame(width: 300, alignment: .bottomTrailing)
                .font(.system(size: self.customValues.titlePizzaSize, weight: .semibold, design: .default))
                .foregroundColor(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
            Text("A typical Neapolitan pizza,\n made with San Marzano \n tomatoes, mozzarella \n cheese, fresh basil, salt \n and extra-virgin olive \n oil. Traditionally, it is \n made with fior di latte \n (milk mozzarella) \n rather than buffalo \n mozzarella.")
                .frame(alignment: .topTrailing)
                .font(.system(size: 12, weight: .regular, design: .default))
                .foregroundColor(Color(self.customValues.descriptionPizzaColor))
                .multilineTextAlignment(.trailing)
                .lineLimit(nil)
            HStack{
                Image(systemName: "star.fill")
                    .font(.system(size: self.customValues.starSize, weight: .regular))
                    .foregroundColor(Color(#colorLiteral(red: 0.9686274509803922, green: 0.7803921568627451, blue: 0.34509803921568627, alpha: 1.0)))
                Image(systemName: "star.fill")
                    .font(.system(size: self.customValues.starSize, weight: .regular))
                    .foregroundColor(Color(#colorLiteral(red: 0.9686274509803922, green: 0.7803921568627451, blue: 0.34509803921568627, alpha: 1.0)))
                Image(systemName: "star.fill")
                    .font(.system(size: self.customValues.starSize, weight: .regular))
                    .foregroundColor(Color(#colorLiteral(red: 0.9686274509803922, green: 0.7803921568627451, blue: 0.34509803921568627, alpha: 1.0)))
                Image(systemName: "star.fill")
                    .font(.system(size: self.customValues.starSize, weight: .regular))
                    .foregroundColor(Color(#colorLiteral(red: 0.9686274509803922, green: 0.7803921568627451, blue: 0.34509803921568627, alpha: 1.0)))
                Image(systemName: "star")
                    .font(.system(size: self.customValues.starSize, weight: .regular))
                    .foregroundColor(Color(#colorLiteral(red: 0.9686274509803922, green: 0.7803921568627451, blue: 0.34509803921568627, alpha: 1.0)))
            }
            
        } .frame(width: 326.268)
    }
}
