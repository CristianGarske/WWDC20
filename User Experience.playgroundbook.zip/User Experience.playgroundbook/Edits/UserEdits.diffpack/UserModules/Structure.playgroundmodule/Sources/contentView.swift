import SwiftUI

let gradientStart = Color(#colorLiteral(red: 0.6, green: 0.6, blue: 0.6, alpha: 1.0))
let gradientEnd = Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0))
let darkText = UIColor(red: 0.267, green: 0.267, blue: 0.267, alpha: 1)


public struct contentView: View{
    @Environment(\.userPreferences) var customValues
    public init() {}
    var congrats: Double {
        let redColors = [Color(#colorLiteral(red: 0.9254901960784314, green: 0.23529411764705882, blue: 0.10196078431372549, alpha: 1.0)), Color(#colorLiteral(red: 0.7450980392156863, green: 0.1568627450980392, blue: 0.07450980392156863, alpha: 1.0)), Color(#colorLiteral(red: 0.9372549019607843, green: 0.34901960784313724, blue: 0.19215686274509805, alpha: 1.0)), Color(#colorLiteral(red: 0.9411764705882353, green: 0.4980392156862745, blue: 0.35294117647058826, alpha: 1.0)), Color(#colorLiteral(red: 0.5215686274509804, green: 0.10980392156862745, blue: 0.050980392156862744, alpha: 1.0)), Color(#colorLiteral(red: 0.3176470588235294, green: 0.07450980392156863, blue: 0.027450980392156862, alpha: 1.0)), Color(#colorLiteral(red: 0.20784313725490197, green: 0.054901960784313725, blue: 0.011764705882352941, alpha: 1.0)), Color(#colorLiteral(red: 0.9568627450980393, green: 0.6588235294117647, blue: 0.5450980392156862, alpha: 1.0))]
        
        let lightColors = [Color(#colorLiteral(red: 0.803921568627451, green: 0.803921568627451, blue: 0.803921568627451, alpha: 1.0)), Color(#colorLiteral(red: 0.6, green: 0.6, blue: 0.6, alpha: 1.0)), Color(#colorLiteral(red: 0.5019607843137255, green: 0.5019607843137255, blue: 0.5019607843137255, alpha: 1.0)), Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)), Color(#colorLiteral(red: 0.4745098039215686, green: 0.8392156862745098, blue: 0.9764705882352941, alpha: 1.0)), Color(#colorLiteral(red: 0.25882352941176473, green: 0.7568627450980392, blue: 0.9686274509803922, alpha: 1.0)), Color(#colorLiteral(red: 0.23921568627450981, green: 0.6745098039215687, blue: 0.9686274509803922, alpha: 1.0)), Color(#colorLiteral(red: 0.17647058823529413, green: 0.4980392156862745, blue: 0.7568627450980392, alpha: 1.0)), Color(#colorLiteral(red: 0.5568627450980392, green: 0.35294117647058826, blue: 0.9686274509803922, alpha: 1.0)), Color(#colorLiteral(red: 0.36470588235294116, green: 0.06666666666666667, blue: 0.9686274509803922, alpha: 1.0)), Color(#colorLiteral(red: 0.9098039215686274, green: 0.47843137254901963, blue: 0.6431372549019608, alpha: 1.0)), Color(#colorLiteral(red: 0.8549019607843137, green: 0.25098039215686274, blue: 0.47843137254901963, alpha: 1.0)), Color(#colorLiteral(red: 0.9568627450980393, green: 0.6588235294117647, blue: 0.5450980392156862, alpha: 1.0)), Color(#colorLiteral(red: 0.9411764705882353, green: 0.4980392156862745, blue: 0.35294117647058826, alpha: 1.0)), Color(#colorLiteral(red: 0.9372549019607843, green: 0.34901960784313724, blue: 0.19215686274509805, alpha: 1.0)), Color(#colorLiteral(red: 0.9764705882352941, green: 0.8509803921568627, blue: 0.5490196078431373, alpha: 1.0)), Color(#colorLiteral(red: 0.9686274509803922, green: 0.7803921568627451, blue: 0.34509803921568627, alpha: 1.0)), Color(#colorLiteral(red: 0.9607843137254902, green: 0.7058823529411765, blue: 0.2, alpha: 1.0)), Color(#colorLiteral(red: 0.9529411764705882, green: 0.6862745098039216, blue: 0.13333333333333333, alpha: 1.0)), Color(#colorLiteral(red: 0.7215686274509804, green: 0.8862745098039215, blue: 0.592156862745098, alpha: 1.0)), Color(#colorLiteral(red: 0.5843137254901961, green: 0.8235294117647058, blue: 0.4196078431372549, alpha: 1.0)), Color(#colorLiteral(red: 0.4666666666666667, green: 0.7647058823529411, blue: 0.26666666666666666, alpha: 1.0)), Color(#colorLiteral(red: 0.3411764705882353, green: 0.6235294117647059, blue: 0.16862745098039217, alpha: 1.0)), Color(#colorLiteral(red: 0.9254901960784314, green: 0.23529411764705882, blue: 0.10196078431372549, alpha: 1.0))]
        if !lightColors.contains(Color(customValues.backgroundPizzaColor)) && !redColors.contains(Color(customValues.orderButtonColor)){
            return 1
        }
        return 0
    }
    
    public var body: some View {
        ZStack{
            Rectangle() //background
                .fill(LinearGradient(gradient: Gradient(colors: [gradientStart, gradientEnd]), startPoint: .top, endPoint: .bottom))
                .scaledToFill()
            VStack{
                Spacer()
                ZStack{ //iPhone
                    Rectangle()  //background (326.268, 699,44)
                        .frame(width: 269.39*1.2, height: 582.87*1.2)
                        .foregroundColor(Color(self.customValues.backgroundPizzaColor))
                    interfaceView()  //interface
                        .frame(width: 269.39*1.2, height: 582.87*1.2)
                    Image(uiImage: #imageLiteral(resourceName: "image 1.png")) //frame
                        .resizable()
                        .frame(width: 318.10*1.2, height: 628.21*1.2)
                    .offset(x: 0.4)
                }
                Spacer()
            }
            experienceArea()
                .offset(x: 260)
            Text("You've made it!")
                .frame(width: 200, height: 20)
                .font(.system(size: 24, weight: .semibold, design: .default))
                .opacity(congrats)
                .foregroundColor(Color(#colorLiteral(red: 0.3411764705882353, green: 0.6235294117647059, blue: 0.16862745098039217, alpha: 1.0)))
                .offset(y: 415)
        
        }
    }
}

