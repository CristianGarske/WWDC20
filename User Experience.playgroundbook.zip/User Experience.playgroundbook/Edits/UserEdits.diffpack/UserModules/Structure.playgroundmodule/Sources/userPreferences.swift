import SwiftUI

private struct UserPreferencesKey: EnvironmentKey {
    static var defaultValue: UserPreferences = UserPreferences()
}

extension EnvironmentValues {
    public var userPreferences: UserPreferences {
        get { self[UserPreferencesKey.self] }
        set { self[UserPreferencesKey.self] = newValue }
    }
}

public struct UserPreferences {
    public let orderTitleWidth: Font.Weight
    public let orderButtonHeight: CGFloat
    public let totalSize: CGFloat
    public let orderButtonColor: UIColor
    public let descriptionPizzaColor: UIColor
    public let backgroundPizzaColor: UIColor
    public let titlePizzaSize: CGFloat
    public let orderButtomTextSize: CGFloat
    public let starSize: CGFloat
    
    public init(
        orderTitleWidth: Font.Weight = .medium,
        orderButtonHeight: CGFloat = 30,
        totalSize: CGFloat = 15,
        orderButtonColor: UIColor = #colorLiteral(red: 0.3411764705882353, green: 0.6235294117647059, blue: 0.16862745098039217, alpha: 1.0),
        descriptionPizzaColor: UIColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0),
        backgroundPizzaColor: UIColor = #colorLiteral(red: 0.03529411764705882, green: 0.11764705882352941, blue: 0.16470588235294117, alpha: 1.0),
        titlePizzaSize: CGFloat = 13,
        orderButtomTextSize: CGFloat = 14,
        starSize: CGFloat = 12
    ) {
        self.orderTitleWidth = orderTitleWidth
        self.orderButtonHeight = orderButtonHeight
        self.totalSize = totalSize
        self.orderButtonColor = orderButtonColor
        self.descriptionPizzaColor = descriptionPizzaColor
        self.backgroundPizzaColor = backgroundPizzaColor
        self.titlePizzaSize = titlePizzaSize
        self.orderButtomTextSize = orderButtomTextSize
        self.starSize = starSize
    }
}
