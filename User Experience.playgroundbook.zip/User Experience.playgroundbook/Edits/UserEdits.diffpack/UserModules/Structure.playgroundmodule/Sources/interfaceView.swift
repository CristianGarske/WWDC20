import SwiftUI

var pizza : some View = Image(uiImage: #imageLiteral(resourceName: "pizza_PNG44095.png"))
    .resizable()
    .frame(width: 350, height: 350)

public struct interfaceView: View{ //App Interface
    public init() {}
    @State var shouldRotate: Bool = false
    public var body: some View {
        ZStack{
            VStack{  //Backcontent
                Image(uiImage: #imageLiteral(resourceName: "Status Bar.png"))
                    .resizable()
                    .frame(width: 270*1.2, height: 29*1.2)
                    .colorInvert()
                HStack{
                    Image(systemName: "chevron.left")
                        .frame(width: 30, height: 25)
                        .font(.system(size: 16, weight: .semibold))
                    Spacer()
                    Text("My Order")
                        .font(.system(size: 16, weight: .semibold, design: .default))
                        .foregroundColor(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                    Spacer()
                    Spacer()
                        .frame(width: 30)
                }.frame(width: 300)
                
                Spacer()
                    .frame(height: 25)
                pizzaDetails()
                Spacer()
            }
            VStack{  //middleContent
                Spacer()
                orderDetails()
            }
            VStack{ //topContent
                pizza
                    .rotationEffect(Angle(degrees: shouldRotate ? 360 : 0))
                    .animation(
                        Animation.linear(duration: 40)
                            .repeatForever(autoreverses: false))
                    .offset(x: -165, y: 90)
                    .clipShape(Rectangle().offset(x: -5, y: 90))
                    .shadow(radius: 10)
                    .onAppear{
                        self.shouldRotate = true
                        
                }
                Spacer()
                Image(uiImage: #imageLiteral(resourceName: "Home Indicator.png"))
            }
        }
    }
}
