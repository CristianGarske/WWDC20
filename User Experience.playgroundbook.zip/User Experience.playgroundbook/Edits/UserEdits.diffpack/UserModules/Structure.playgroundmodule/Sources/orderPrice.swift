import SwiftUI


public struct orderPrice: View{
    @Environment(\.userPreferences) var customValues
    public init() {}
    public var body: some View{
        VStack{
            HStack{  //subtotal
                Text("Subtotal")
                    .frame(width: 70, height: 25, alignment: .leading)
                    .font(.system(size: 13, weight: .semibold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                Spacer()
                Text("$26,00")
                    .frame(width: 50, alignment: .topTrailing)
                    .font(.system(size: 13, weight: .semibold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
            }
            HStack{   //delivery fee
                Text("Delivery Fee")
                    .frame(width: 100, height: 25, alignment: .leading)
                    .font(.system(size: 13, weight: .semibold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                Spacer()
                Text("$3,00")
                    .frame(width: 50, alignment: .topTrailing)
                    .font(.system(size: 13, weight: .semibold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
            }
            HStack{
                Text("Total")
                    .frame(width: 70, height: 25, alignment: .leading)
                    .font(.system(size: customValues.totalSize, weight: .semibold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
                Spacer()
                Text("$29,00")
                    .frame(width: 70, alignment: .topTrailing)
                    .font(.system(size: customValues.totalSize, weight: .semibold, design: .default))
                    .foregroundColor(Color(#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)))
            }
            
        }
    }
}
