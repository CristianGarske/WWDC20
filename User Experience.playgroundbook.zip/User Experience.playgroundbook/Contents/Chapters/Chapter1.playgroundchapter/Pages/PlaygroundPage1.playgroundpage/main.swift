//#-hidden-code

import PlaygroundSupport
import SwiftUI

var orderButtonHeight: CGFloat = 30
var starSize: CGFloat = 23
var titlePizzaSize: CGFloat = 30
var orderTitleWidth: Font.Weight = .light
var orderButtomTextSize: CGFloat = 11
var backgroundPizzaColor: UIColor = #colorLiteral(red: 0.803921568627451, green: 0.803921568627451, blue: 0.803921568627451, alpha: 1.0)
var orderButtonColor: UIColor = #colorLiteral(red: 0.9372549019607843, green: 0.34901960784313724, blue: 0.19215686274509805, alpha: 1.0)
var descriptionPizzaColor: UIColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
var totalSize: CGFloat = 17 //ideal: 15


//#-end-hidden-code
/*:

# Welcome!

In this Swift Playground, you'll help the developers of this this food app to improve their bad design, using the Apple Guidelines in 1 minute!

*/


/*:

# What is Human Interface Guidelines?

Well, the Human Interface Guidelines aim to improve the experience for the users by making application interfaces more intuitive, learnable, and consistent. They're used across all Apple products!  HIGs often describe the visual design rules, including icon and window design and style.

### So, we'll focus on:

1. the size of some elements,
2. the text hierarchy and
3. the colors!

*/


/*:
- - - -
# 1 - The best size of interactive elements

- - - -
The Human Interface Guidelines orient us to give all controls and interactive elements a hit target that measures at least __44pt x 44pt__. Controls that are too small can be frustratingly difficult for all users to hit. As you can see, the "Order Pizza" does not follow the guidelines. It have a small height, not focusing on the accessibility.

- - - -
1. Increase the height of the "Order Pizza" button.,
2. Hit "Run My Code”
- - - -
*/

// Try following the Human Interface Guidelines, using 44!
orderButtonHeight = /*#-editable-code number of repetitions*/30/*#-end-editable-code*/

/*:
- - - -
The 5 stars of the pizza description are a good way to check the quality of the product! The user can discover the other people ratings and comments. But here they're too big, not fitting in the spacce and being confused for the user to understand.

1. Decrease the size of the stars,
2. Hit "Run My Code”
- - - -
*/

// A good size is 13, but you can try other sizes!
starSize = /*#-editable-code number of repetitions*/23/*#-end-editable-code*/

/*:
- - - -
 
 
# 2 - Text hierarchy
- - - -
Text is the primary unit of informational content, which is exactly the reason why it must always be legible and organized. Properly formatted text facilitates users’ perception of information. For information hierarchy to be clearly visible, always start with a big title which should be the most prominent element of the page. Sub-headers and other text should be considerably smaller, and so on.
- - - -
1. Increase the size of the "Margherita" title,
2. Hit "Run My Code”
- - - -
*/

// For the title you can use from 17 to 30! Experiment what does better for the Title!
titlePizzaSize = /*#-editable-code number of repetitions*/12/*#-end-editable-code*/

/*:
- - - -
The Human Interface Guidelines orients us to avoid using UltraLight, Thin, and Light font weights, which can be more difficult to see.
- - - -
1. Change the weight of the "Order Details" title.
2. Hit "Run My Code”
- - - -
*/

// Try to use .regular, .medium, .semibold, or .bold for the font weights, because they are easier to see.
orderTitleWidth = /*#-editable-code number of repetitions*/.light/*#-end-editable-code*/

/*:
- - - -
The text inside the "Order Pizza" button have a bad readability, because it have a small size!

- - - -
1. Increase the weight of the "Order Details" title,
2. Hit "Run My Code”
- - - -
*/

// The regular size of the body text is 17. Give a try!
orderButtomTextSize = /*#-editable-code number of repetitions*/11/*#-end-editable-code*/

/*:

# 3 - Color and Contrast
- - - -

The contrast of colors could be improved! We need to use strongly contrasting colors to improve readability. The pizza background color could be darker, as a way to create a good contrast with the image and the text.

- - - -
1. Select the square below to customize the color of the background,
2. Hit "Run My Code”
- - - -
*/

// You can choose a dark blue color, or test all the dark colors!
backgroundPizzaColor = /*#-editable-code number of repetitions*/#colorLiteral(red: 0.6, green: 0.6, blue: 0.6, alpha: 1.0)/*#-end-editable-code*/

/*:

The color red, when used in a button, is commonly associated with an alert, danger or undoing an action. Let's change the "Order Pizza" button for other color!

- - - -
1. Select the square below to customize the color of the "Order Pizza" button,
2. Hit "Run My Code”
- - - -
*/

// Try avoiding shades of red, even gray or white, as a way to keep a good contrast!
orderButtonColor = /*#-editable-code number of repetitions*/#colorLiteral(red: 0.9372549019607843, green: 0.34901960784313724, blue: 0.19215686274509805, alpha: 1.0)/*#-end-editable-code*/

/*:

# You've made it!😍🥇
- - - -
### Thank you for helping improve the usability of our app! 🙌🏻

### Now we can test again with the users and soon it will be in the App Store! 📲

### Ask for a pizza! You deserve one! 🍕🥳

*/


/*:
- - - -
# About Me

Hello, My name is Cristian Garske, I'm 29 years old, I'm a Design student at Universidade Federal do Rio Grande do Sul (UFRGS). I am a UX Design student at the Apple Developer Academy - Porto Alegre, Brazil. I started developing for iOS two years ago. Last year, I published my first app with a group of Apple Academy colleagues, at the App Store. The app is called Bubble Yonder and is aimed at facilitating the routines of children in the spectrum of autism. I did all the design part, and this playground is the first coding stuff i did, after watching a lot of Swift Classes last year and even online courses.

Apple Developer Academy PUCRS - Porto Alegre, Brazil.

* [My site](https://cristiangars.com)
* [My LinkedIn](https://www.linkedin.com/in/cristiangarske)
- - - -
*/


/*:
- - - -
# References

* [Apple Human Interface Guidelines](https://developer.apple.com/design/human-interface-guidelines)
* [Design For Everyone](https://developer.apple.com/videos/play/wwdc2017/806/)
* [Accessibility for Developers](https://developer.apple.com/accessibility/)
* [Free Pizza Image](https://pngimg.com/download/44095)
- - - -
*/




//#-hidden-code



let customValues = UserPreferences(
    orderTitleWidth: orderTitleWidth,
    orderButtonHeight: orderButtonHeight,
    totalSize: totalSize,
    orderButtonColor: orderButtonColor,
    descriptionPizzaColor: descriptionPizzaColor,
    backgroundPizzaColor: backgroundPizzaColor,
    titlePizzaSize: titlePizzaSize,
    orderButtomTextSize: orderButtomTextSize,
    starSize: starSize)


PlaygroundPage.current.setLiveView(contentView().environment(\.userPreferences, customValues))
//#-end-hidden-code
